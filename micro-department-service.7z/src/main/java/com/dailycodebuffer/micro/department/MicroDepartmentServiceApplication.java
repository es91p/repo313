package com.dailycodebuffer.micro.department;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroDepartmentServiceApplication {

	public static void main(String[] args) {
		System.out.println("Entry into MicroDepartmentServiceApplication - main()");
		SpringApplication.run(MicroDepartmentServiceApplication.class, args);
		System.out.println("Exit from MicroDepartmentServiceApplication - main()");
		
	}

}
