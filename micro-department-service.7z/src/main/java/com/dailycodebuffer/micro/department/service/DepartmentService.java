package com.dailycodebuffer.micro.department.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dailycodebuffer.micro.department.controller.DepartmentController;
import com.dailycodebuffer.micro.department.entity.Department;
import com.dailycodebuffer.micro.department.repository.DepartmentRepository;

@Service
public class DepartmentService {
	Logger logger = LoggerFactory.getLogger(DepartmentService.class);
	@Autowired
	DepartmentRepository departmentRepository;

	public Department saveDepartment(Department department) {
		logger.info("Inside DepartmentService class method - saveDepartment()");
		return departmentRepository.save(department);
	}

	public Department findDepartmentById(Long  departmentId) {
		logger.info("Inside DepartmentService class method - findDepartmentById()");
		return departmentRepository.findByDepartmentId(departmentId);
	}
}
