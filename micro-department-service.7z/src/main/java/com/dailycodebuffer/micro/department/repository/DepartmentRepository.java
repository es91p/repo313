package com.dailycodebuffer.micro.department.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dailycodebuffer.micro.department.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

	Department save(Department department);

	
	Department findByDepartmentId(Long deparmentId);

}
